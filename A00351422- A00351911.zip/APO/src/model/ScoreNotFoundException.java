package model;

public class ScoreNotFoundException extends Exception{

	public ScoreNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ScoreNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
