package model;



public interface Colisionable {
	public final static int SIZE = 25;
	public boolean isColision(Colisionable c);
	public void hayColision(Colisionable c);
	
}
