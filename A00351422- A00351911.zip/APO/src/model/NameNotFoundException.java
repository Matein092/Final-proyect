package model;

public class NameNotFoundException extends Exception{

	private static final long serialVersionUID = 1L;

	public NameNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public NameNotFoundException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}
}
