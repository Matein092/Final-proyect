package model;

public class PlayerRepetidoException extends Exception {
	private static final long serialVersionUID = 2L;
	
	private String message;
	
	public PlayerRepetidoException(String name) {
		this.message=name;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
