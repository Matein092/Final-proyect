package model;

public interface Movible {
	
	public void move();
}
