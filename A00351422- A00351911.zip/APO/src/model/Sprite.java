package model;

public class Sprite{
	
	private int width;
	
	private int height;
	
	private int speed;
	
	private boolean visible;
	
	public Sprite( int width, int height, int speed) {
		this.width = width;
		this.height = height;
		this.speed = speed;
		visible = true;
	}

	
	public int getSpeed() {
		return speed;
	}


	public void setSpeed(int speed) {
		this.speed = speed;
	}


	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}
	
	
}
