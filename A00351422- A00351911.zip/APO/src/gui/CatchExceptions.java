package gui;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CatchExceptions {

	public CatchExceptions() {
		// TODO Auto-generated constructor stub
	}
	
	public void ValidateFieldsEmptys(String fname, String fedad) throws CustomException{
		if(fname.trim().isEmpty() && fedad.trim().isEmpty()){
			throw new CustomException("Los campos estan vacios...");
		}else if(fname.trim().isEmpty()){
			throw new CustomException("Los campos estan vacios...");
		}else if(fedad.trim().isEmpty()){
			throw new CustomException("Los campos estan vacios...");
		}else{
			System.out.println("Datos completos, listo para guardar la data");
		}
	}
	
	
	public void ValidateLengthEdad(String fedad) throws ExceptionInteger{
		if(Integer.parseInt(fedad.trim()) > 80){
			throw new ExceptionInteger(" El jugador no puede ser mayor a 80, por que no presenta las condiciones para jugar");
		}
	}
	
	
	public void ValidateExpresionsRegular(String fname, String fedad) throws ExceptionRegularExpression{
		String REG_EXP = "\\�+|\\?+|\\�+|\\�+|\\|+|\\!+|\\#+|\\$+|" +
				"\\%+|\\&+|\\+|\\=+|\\�+|\\�+|\\++|\\*+|\\~+|\\[+|\\]" +
				"+|\\{+|\\}+|\\^+|\\<+|\\>+|\\\"+";
		Pattern pattername = Pattern.compile(REG_EXP);
		Matcher matchername = pattername.matcher(fname);
		
		Pattern patternedad = Pattern.compile(REG_EXP);
		Matcher matcheredad = patternedad.matcher(fedad);
		
		if (matchername.find()) { 
			throw new ExceptionRegularExpression(" Caracteres no permitidos");
		}else if(matcheredad.find()){
			throw new ExceptionRegularExpression(" Caracteres no permitidos");
		} 
		
		
	}
}
