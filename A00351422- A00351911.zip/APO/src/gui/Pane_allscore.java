package gui;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.Player;

public class Pane_allscore {
	
		
	private ArrayList<Player> p = new ArrayList<>();
	
	public Pane_allscore(Stage stage){
		Group group = new Group();
		Scene scene = new Scene(group);
		stage.setTitle("Todos los puntajes");
		stage.setWidth(400);
		stage.setHeight(300);
		
		Text t = new Text("PUNTAJE DE LOS USUARIOS");
		t.setLayoutY(30);
		t.setLayoutX(30);
		
		Text tJ = new Text("JUADOR");
		tJ.setLayoutY(60);
		tJ.setLayoutX(30);
		
		Text tE = new Text("EDAD");
		tE.setLayoutY(60);
		tE.setLayoutX(140);
		
		
		Text tp = new Text("PUNTAJE");
		tp.setLayoutY(60);
		tp.setLayoutX(210);
		
		

		group.getChildren().addAll(t);
		group.getChildren().addAll(tJ);
		group.getChildren().addAll(tE);
		group.getChildren().addAll(tp);
		Text loadinfo = new Text();
		try {
			loadinfo = new Text(readFile());
			loadinfo.setLayoutY(90);
			loadinfo.setLayoutX(30);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		group.getChildren().addAll(loadinfo);
		stage.setScene(scene);
	}
	
	
	public String readFile() throws FileNotFoundException, IOException{
		File archivo = new File ("users.txt");
		String linea;
		FileReader fr = new FileReader (archivo);
		BufferedReader br = new BufferedReader(fr);
		
		String text = "";
		
		while((linea=br.readLine())!=null){
			text += linea.replaceAll("USER:", " ").replaceAll(";", "  -  ").replaceAll("EDAD:", "        ").replaceAll("SCORE:", "                ")+"\n";
		}
		
		return text;
		
	     
	}
	
	
}
