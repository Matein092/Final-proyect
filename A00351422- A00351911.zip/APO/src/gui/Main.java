package gui;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.stage.Stage;
import model.*;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;


public class Main extends Application{
	
	Stage window;
	Scene main,gamepanel;
	
	private boolean statescene = false;
	private boolean showGame = false;
	
	static Sprite sprite = new Sprite(20, 20, 5);
	private int valocidad = sprite.getSpeed();
	static int foodcolor = 0;
	static int width = 18;
	static int height = 20;
	static Food food = new Food(0, 0);
	static int foodX = 0;
	static int foodY = 0;
	private Player p;
	static int cornersize = 25;
	static List<Corner> snake = new ArrayList<>();
	static Dir direction = Dir.left;
	static boolean gameOver = false;
	static Random rand = new Random();
	private static AnimationTimer timers;
	
	
	public enum Dir {
		left, right, up, down
	}
	
	public void writeNewUser(TextField fname, TextField fedad) {      
	    PrintWriter fw = null;
	    try {
	        //fw = new PrintWriter("users.txt");
	    	File file_ = new File("users.txt");
	    	
	    	if(!file_.exists()){
	    		BufferedWriter bw = new BufferedWriter(new FileWriter("users.txt"));
	 	        bw.write("PLAYER:"+fname.getText().trim()+";AGE:"+fedad.getText().trim());
	 	        bw.close();
	    	}else{
	    		 String cadena;
	   	         FileReader f;
	   	      try {
			   			f = new FileReader("users.txt");
			   			BufferedReader b = new BufferedReader(f);
			   			String data = "";
			   			int count = 0;
			   		     while((cadena = b.readLine())!=null) {
			   		    	 if(count == 1){
			   		    		 data += cadena+"\n";
			   		    	 }else if(count == 2){
			   		    		 data += cadena+"\n";
			   		    	 }else{
			   		    		 data += cadena+"\n";
			   		    	 }
			   		    	 
			   		    	 
			   		         count++;
			   		     }
			   		     b.close();
	   		     
				   		 BufferedWriter bw = new BufferedWriter(new FileWriter("users.txt"));
				   		 bw.write(data);
				   		 bw.newLine();
				   		 bw.write("PLAYER:"+fname.getText().trim()+";AGE:"+fedad.getText().trim());
			 	         bw.newLine();
			 	         bw.close();
	   		     
			   		} catch (FileNotFoundException e) {
			   			
			   			e.printStackTrace();
			   		}
	    	}
	       
	    } catch (IOException e) {
	        e.printStackTrace();
	        fw.close();
	    }
	    
	    
	}
	
	private void showAlertSave() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Save data");
        alert.setHeaderText(null);
        alert.setContentText("CONGRATULATION YOU HAVE BEEN REGITER"); 
        alert.showAndWait();
    }
	private void alertByName() {
		Alert alert = new Alert(AlertType.ERROR);
	    alert.setTitle("Name Repedito");
	    alert.setHeaderText(null);
	    alert.setContentText("THE NAME WRITE HAS BEEN IN THE WINDOW"); 
	    alert.showAndWait();
	}
	private void alertNula() {
		Alert alert = new Alert(AlertType.ERROR);
	    alert.setTitle("Campos vacios");
	    alert.setHeaderText(null);
	    alert.setContentText("Error fatal! \t Campos vacios"); 
	    alert.showAndWait();
	}
	
    
	public void validateData(TextField fname, TextField fedad) throws PlayerRepetidoException, NullPointerException{
		try {
			if(fname.getText().trim().isEmpty() || fedad.getText().trim().isEmpty())
				throw new NullPointerException();
			else 
				p = new Player(fname.getText().trim());
				p.insertByName(p);
		}catch (NullPointerException e) {
			alertNula();
			
		}catch(PlayerRepetidoException e) {
			alertByName();
		}
		
	}
	
	public void saveData(TextField fname, TextField fedad,Stage primaryStage){
			writeNewUser(fname,fedad);
			showAlertSave();
			showGame = true;
			SceneGame(primaryStage);
	}
	
	public void showAllscore(Stage stage){
		new Pane_allscore(stage);
	}
	public void showMessage(Stage primary) throws PlayerRepetidoException{
		Image image = new Image("gui/background.png");
		ImageView mv = new ImageView(image);
		mv.setFitWidth(550);
		mv.setFitHeight(455);
		mv.setLayoutY(0);
		
		//Image for icon to form register
		
		Image imageIcon = new Image("gui/snake_logotype.png");
		ImageView mvIcon = new ImageView(imageIcon);
		mvIcon.setFitWidth(110);
		mvIcon.setFitHeight(110);
		mvIcon.setLayoutY(16);
		mvIcon.setLayoutX(218);
		
		Text t = new Text();
		t.setText("WELCOME!");
		t.setY(150);
		t.setX(220);
		t.setTextAlignment(TextAlignment.CENTER);
		t.getStyleClass().add("titlew");
		
		Text description = new Text();
		description.setText("Put yours dates,�Are you ready to stay in the hall of fame?");
		description.setTextAlignment(TextAlignment.CENTER);
		description.setY(170);
		description.setX(80);
		description.setWrappingWidth(400);
		description.getStyleClass().add("description");
		
		
		//Labels for form
		
		Label lbname = new Label("NICKNAME");
		lbname.setLayoutY(220);
		lbname.setLayoutX(100);
		lbname.getStyleClass().add("lbname");
		
		Label lbedad = new Label("AGE");
		lbedad.setLayoutY(300);
		lbedad.setLayoutX(100);
		lbedad.getStyleClass().add("lbedad");
		
		
		//Inputs for form
		
		TextField fieldname = new TextField();
		fieldname.setLayoutY(245);
		fieldname.setLayoutX(100);
		fieldname.getStyleClass().add("fieldname");
		
		
		TextField fieldedad = new TextField();
		fieldedad.setLayoutY(320);
		fieldedad.setLayoutX(100);
		fieldedad.getStyleClass().add("fieldedad");
		
		//Buttons for form
		
		Button btnadd = new Button("REGISTER");
		btnadd.setLayoutY(385);
		btnadd.setLayoutX(100);
		btnadd.getStyleClass().add("btnadd");
		
		
		
		Button btnview = new Button("HALL OF FAME");
		btnview.setLayoutY(385);
		btnview.setLayoutX(260);
		btnview.getStyleClass().add("btnview");
		
		Group root_ = new Group();
		root_.getChildren().addAll(mv);
		root_.getChildren().addAll(mvIcon);
		root_.getChildren().addAll(t);
		root_.getChildren().addAll(description);
		root_.getChildren().addAll(lbname);
		root_.getChildren().addAll(fieldname);
		root_.getChildren().addAll(lbedad);
		root_.getChildren().addAll(fieldedad);
		root_.getChildren().addAll(btnadd);
		root_.getChildren().addAll(btnview);
		
		//Add events
		
		btnadd.setOnAction(e -> {
			saveData(fieldname, fieldedad, primary);
		});
		btnview.setOnAction(e -> showAllscore(primary));
		Scene scene2 = new Scene(root_,550,455);
		scene2.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		
		primary.setScene(scene2);
	}
	
	
	public static void addScore() throws FileNotFoundException, IOException{
		
		timers.stop();
		
		  String cadena;
	      FileReader f;
		try {
			f = new FileReader("users.txt");
			BufferedReader b = new BufferedReader(f);
			String data = "";
			int count = 0;
		     while((cadena = b.readLine())!=null) {
		    	 
		    	 if(count ==1){
		    		 data += cadena+"\n";
		    	 }else if(count ==2){
		    		 data += cadena;
		    	 }else if(count > 2){
		    		 data += cadena+"\n";
		    	 }else{
		    		 data += cadena;
		    	 }
		    	 
		    	 
		         count++;
		     }
		     b.close();
		     
		     BufferedWriter bw = new BufferedWriter(new FileWriter("users.txt"));
		     bw.write(data);
		     bw.write(";SCORE:"+(sprite.getSpeed() - 6)+";");
		     bw.close();
		     
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	      
	}
	
	
	// tick
		public static void tick(GraphicsContext gc) {
			if (gameOver) {
				gc.setFill(Color.RED);
				gc.setFont(new Font("", 50));
				gc.fillText("GAME OVER", 100, 250);
				try {
					addScore();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				return;
			}

			for (int i = snake.size() - 1; i >= 1; i--) {
				snake.get(i).x = snake.get(i - 1).x;
				snake.get(i).y = snake.get(i - 1).y;
			}

			switch (direction) {
			case up:
				snake.get(0).y--;
				if (snake.get(0).y < 0) {
					gameOver = true;
				}
				break;
			case down:
				snake.get(0).y++;
				if (snake.get(0).y > height) {
					gameOver = true;
				}
				break;
			case left:
				snake.get(0).x--;
				if (snake.get(0).x < 0) {
					gameOver = true;
				}
				break;
			case right:
				snake.get(0).x++;
				if (snake.get(0).x > width) {
					gameOver = true;
				}
				break;

			}

			// eat food
			if (foodX == snake.get(0).x && foodY == snake.get(0).y) {
				snake.add(new Corner(-1, -1));
				newFood();
			}

			// self destroy
			for (int i = 1; i < snake.size(); i++) {
				if (snake.get(0).x == snake.get(i).x && snake.get(0).y == snake.get(i).y) {
					gameOver = true;
				}
			}

			// fill
			// background
			gc.setFill(Color.BLACK);
			gc.fillRect(0, 0, width * cornersize, height * cornersize);

			// score
			gc.setFill(Color.WHITE);
			gc.setFont(new Font("", 30));
			gc.fillText("Score: " + (sprite.getSpeed() - 6), 10, 30);

			// random foodcolor
			Color cc = Color.WHITE;
			Color cc1 = Color.WHITE;
			
			switch (foodcolor) {
			case 0:
				cc = Color.PURPLE;
				break;
			case 1:
				cc = Color.LIGHTBLUE;
				break;
			case 2:
				cc = Color.YELLOW;
				break;
			case 3:
				cc = Color.PINK;
				break;
			case 4:
				cc = Color.ORANGE;
				break;
			}
			switch (foodcolor) {
			case 0:
				cc1 = Color.BROWN;
				break;
			case 1:
				cc1 = Color.WHITE;
				break;
			case 2:
				cc1 = Color.BLUE;
				break;
			case 3:
				cc1 = Color.GREEN;
				break;
			case 4:
				cc1 = Color.PURPLE;
				break;
			}
			
			gc.setFill(cc);
			gc.fillRect(foodX * cornersize, foodY * cornersize, cornersize-2, cornersize-2);
			

			// snake
			for (Corner c : snake) {
				gc.setFill(cc1);
				gc.fillRect(c.x * cornersize, c.y * cornersize, cornersize - 1, cornersize - 1);

			}

		}

		// food
		public static void newFood() {
			start: while (true) {
				foodX = rand.nextInt(width);
				foodY = rand.nextInt(height);

				for (Corner c : snake) {
					if (c.x == foodX && c.y == foodY) {
						continue start;
					}
				}
				foodcolor = rand.nextInt(5);
				int speed1 = sprite.getSpeed();
				speed1++;
				sprite.setSpeed(speed1);
				break;

			}
		}

	public void SceneGame(Stage primaryStage){
		
		if(showGame){
			
		
				newFood();
		
				VBox root = new VBox();
				Canvas c = new Canvas(width * cornersize, height * cornersize);
				GraphicsContext gc = c.getGraphicsContext2D();
				root.getChildren().add(c);
		
				timers = new AnimationTimer() {
					long lastTick = 0;
		
					public void handle(long now) {
						if (lastTick == 0) {
							lastTick = now;
							tick(gc);
							return;
						}
		
						if (now - lastTick > 1000000000 / sprite.getSpeed()) {
							lastTick = now;
							tick(gc);
						}
					}
		
				};
				
				timers.start();
		
				Scene scene = new Scene(root, width * cornersize, height * cornersize);
		
				// control
				scene.addEventFilter(KeyEvent.KEY_PRESSED,
		                event -> System.out.println("Pressed: " + event.getCode()));
				scene.addEventFilter(KeyEvent.KEY_PRESSED, key -> {
					if (key.getCode() == KeyCode.UP) {
						direction = Dir.up;
					}
					if (key.getCode() == KeyCode.LEFT) {
						direction = Dir.left;
					}
					if (key.getCode() == KeyCode.DOWN) {
						direction = Dir.down;
					}
					if (key.getCode() == KeyCode.RIGHT) {
						direction = Dir.right;
					}
		
				});
		
				// add start snake parts
				snake.add(new Corner(width / 2, height / 2));
				snake.add(new Corner(width / 2, height / 2));
				snake.add(new Corner(width / 2, height / 2));
		
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStage.setScene(scene);
				primaryStage.setTitle("SNAKE GAME");
				//primaryStage.show();
		}
	}
	
	@Override
	public void start(Stage primaryStage) {
		try {
			
			Image image = new Image("gui/snake1.png");
			ImageView mv = new ImageView(image);
			mv.setFitWidth(550);
			mv.setFitHeight(455);
			mv.setLayoutY(0);
			
			Text t = new Text();
			t.setText("�ARE YOU READY FOR THIS AWESOME PROYECT?");
			t.setWrappingWidth(400);
			t.setFont(Font.font ("Verdana", 12));
			t.setFill(Color.BLACK);
			t.setY(350);
			t.setX(80);
			t.setTextAlignment(TextAlignment.CENTER);
			
			Button btnstart = new Button("START GAME");
			btnstart.setTranslateY(403);
			btnstart.setTranslateX(174);
			btnstart.getStyleClass().add("button1");
			
			
			
			Group root = new Group();
			root.getChildren().addAll(mv);
			root.getChildren().addAll(t);
			root.getChildren().addAll(btnstart);
			Scene scene = new Scene(root,550,455);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			
			btnstart.setOnAction(e -> {
				try {
					showMessage(primaryStage);
				} catch (PlayerRepetidoException e1) {
					alertByName();
				}
			});
			
			if(statescene == false || showGame == false){
				primaryStage.setScene(scene);
			}
			
			SceneGame(primaryStage);
			
			
			primaryStage.setTitle("START GAME");
			primaryStage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public int getSpeed(){
		return this.valocidad;
	}
	
	
	public void setFillGreen(GraphicsContext gc) {
		gc.setFill(javafx.scene.paint.Color.GREEN);
	}
	
	public void setFillYellow(GraphicsContext gc) {
		gc.setFill(javafx.scene.paint.Color.YELLOW);
	}
	
	public void setFillRed(GraphicsContext gc) {
		gc.setFill(javafx.scene.paint.Color.RED);
	}
	
	public void setFilleWhite(GraphicsContext gc) {
		gc.setFill(javafx.scene.paint.Color.WHITE);
	}
	public static void main(String[] args) {
		launch(args);
	}	
}
