package gui;

public class ExceptionRegularExpression extends Exception{
	
	
	public final static long serialVersionUID = 700L;
	
	public ExceptionRegularExpression(String Message) {
		// TODO Auto-generated constructor stub
		super(Message);
	}

}
