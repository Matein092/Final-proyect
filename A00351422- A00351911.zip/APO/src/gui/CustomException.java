package gui;

public class CustomException extends Exception{
	
	
	public final static long serialVersionUID = 700L;
	
	public CustomException(String Message) {
		super(Message);
	}

}
