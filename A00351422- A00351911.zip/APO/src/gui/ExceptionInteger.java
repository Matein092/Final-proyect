package gui;


public class ExceptionInteger extends Exception{
	
	
	public final static long serialVersionUID = 700L;
	
	public ExceptionInteger(String Message) {
		// TODO Auto-generated constructor stub
		super(Message);
	}

}
