import static org.junit.Assert.*;

import org.junit.Test;

import application.Main;

public class GameTest {
	
	private Main classMain main;
	
	@Test
	public void setUpScenary1() {
		classMain = new Main;
	}
	
	public void scenary1(){
		setUpScenary1()
		
		int result = classmain.getSpeed();
		int esperado = 15;
		
		assertEquals(esperado, result);
	}
	
	
	
	
	public void scenary2(){
		
		setUpScenary1;
		int result = (classmain.getSpeed()-6);
		int esperado = 5;
		
		assertEquals(esperado, result);
	}
	
	
	public void scenary3() {
		setUpScenary1;
		gui.Main classMain = new Main();
		String nickName = mateo;
		String age = 14000;
		String nickName1 = mateo;
		String age = 3;
		classMain.validateData(nickName, age);
		assertTrue("If the method throw an exception", classMain.validateData(nickName1, age));
		
	}
	
	public void scenary4() {
		setUpScenary1();
		
	}

}
